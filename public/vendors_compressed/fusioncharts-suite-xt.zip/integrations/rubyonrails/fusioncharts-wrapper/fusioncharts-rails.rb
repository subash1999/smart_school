require "erb"
require "json"
require "fusioncharts/rails/version"
require "fusioncharts/rails/chart"